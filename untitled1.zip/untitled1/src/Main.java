import java.util.Scanner;

public class Main {
    private static final int DAYS_IN_MONTH = 30;
    private static int[] expenses = new int[DAYS_IN_MONTH + 1]; // Индексы с 1 по 30

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Меню:");
            System.out.println("1 – Ввести расходы за определенный день");
            System.out.println("2 – Траты за месяц");
            System.out.println("3 – Самая большая сумма расхода за месяц");
            System.out.println("0 – Выход");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    enterExpenses(scanner);
                    break;
                case 2:
                    showExpenses();
                    break;
                case 3:
                    showMaxExpenseDay();
                    break;
                case 0:
                    System.out.println("Прощайте!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Некорректный выбор. Попробуйте снова.");
            }
        }
    }

    private static void enterExpenses(Scanner scanner) {
        System.out.print("Введите день (от 1 до 30): ");
        int day = scanner.nextInt();

        if (day < 1 || day > DAYS_IN_MONTH) {
            System.out.println("Некорректный день. Повторите ввод.");
            return;
        }

        if (expenses[day] > 0) {
            System.out.println("Траты за " + day + " день уже указаны: " + expenses[day] + " руб.");
            System.out.print("Желаете перезаписать сумму? (1 - Да, 0 - Нет): ");
            int overwriteChoice = scanner.nextInt();
            if (overwriteChoice == 1) {
                System.out.print("Введите новую сумму трат: ");
                expenses[day] = scanner.nextInt();
                System.out.println("Сумма трат успешно перезаписана.");
            } else {
                System.out.println("Сумма трат оставлена без изменений.");
            }
        } else {
            System.out.print("Введите сумму трат за " + day + " день: ");
            expenses[day] = scanner.nextInt();
            System.out.println("Сумма трат успешно записана.");
        }

        System.out.print("Желаете ввести траты за другой день? (1 - Да, 0 - Вернуться в меню): ");
        int anotherDayChoice = scanner.nextInt();
        if (anotherDayChoice == 1) {
            enterExpenses(scanner);
        }
    }

    private static void showExpenses() {
        System.out.println("Траты за месяц:");
        for (int i = 1; i <= DAYS_IN_MONTH; i++) {
            System.out.println(i + " день – " + expenses[i] + " руб");
        }
        System.out.println("Нажмите 0, чтобы вернуться в меню.");
        while (true) {
            int choice = new Scanner(System.in).nextInt();
            if (choice == 0) {
                break;
            } else {
                System.out.println("Некорректный выбор. Попробуйте снова.");
            }
        }
    }

    private static void showMaxExpenseDay() {
        int maxExpense = 0;
        int dayWithMaxExpense = 0;

        for (int i = 1; i <= DAYS_IN_MONTH; i++) {
            if (expenses[i] > maxExpense) {
                maxExpense = expenses[i];
                dayWithMaxExpense = i;
            }
        }

        if (maxExpense > 0) {
            System.out.println(dayWithMaxExpense + " день – " + maxExpense + " руб");
        } else {
            System.out.println("Нет записей о тратах за месяц.");
        }

        System.out.println("Нажмите 0, чтобы вернуться в меню.");
        while (true) {
            int choice = new Scanner(System.in).nextInt();
            if (choice == 0) {
                break;
            } else {
                System.out.println("Некорректный выбор. Попробуйте снова.");
            }
        }
    }
}
